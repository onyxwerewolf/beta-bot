<?php

define('BOT_API','');
define('BOT_USERNAME','');
define('HOOK_URL','https://www.YOUR_SITE.ir/hook2.php');
define('Proxy','localhost:56176');
define('BASE_DIR',__DIR__."/");
define('JOIN_URL','https://t.me/OnyxWereBetaBot?start=joinToGAME_');
define('Challenge_URL','https://t.me/OnyxWereBetaBot?start=ChallengeJoin_');
define('ADMIN_ID','BOT Admin ID');