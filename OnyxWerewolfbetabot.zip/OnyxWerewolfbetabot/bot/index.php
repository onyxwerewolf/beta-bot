<?php
die('Access Dined');